const Hotel = require('../models/Hotel');
const Room = require('../models/Room');
const Booking = require('../models/Booking');
const User = require('../models/User');

const getDashboardStats = async (req, res) => {
  try { res.json({ success: true, stats: await Booking.getDashboardStats() }); }
  catch (e) { res.status(500).json({ message: 'Server error' }); }
};
const createHotel = async (req, res) => {
  try { const id = await Hotel.create(req.body); res.status(201).json({ success: true, hotel: await Hotel.findById(id) }); }
  catch (e) { res.status(500).json({ message: 'Server error' }); }
};
const updateHotel = async (req, res) => {
  try { (await Hotel.update(req.params.id, req.body)) ? res.json({ success: true }) : res.status(404).json({ message: 'Hotel not found' }); }
  catch (e) { res.status(500).json({ message: 'Server error' }); }
};
const deleteHotel = async (req, res) => {
  try { (await Hotel.delete(req.params.id)) ? res.json({ success: true }) : res.status(404).json({ message: 'Hotel not found' }); }
  catch (e) { res.status(500).json({ message: 'Server error' }); }
};
const createRoom = async (req, res) => {
  try { const id = await Room.create(req.body); res.status(201).json({ success: true, room: await Room.findById(id) }); }
  catch (e) { res.status(500).json({ message: 'Server error' }); }
};
const updateRoom = async (req, res) => {
  try { (await Room.update(req.params.id, req.body)) ? res.json({ success: true }) : res.status(404).json({ message: 'Room not found' }); }
  catch (e) { res.status(500).json({ message: 'Server error' }); }
};
const deleteRoom = async (req, res) => {
  try { (await Room.delete(req.params.id)) ? res.json({ success: true }) : res.status(404).json({ message: 'Room not found' }); }
  catch (e) { res.status(500).json({ message: 'Server error' }); }
};
const getAllBookings = async (req, res) => {
  try { res.json({ success: true, bookings: await Booking.getAllBookings(req.query) }); }
  catch (e) { res.status(500).json({ message: 'Server error' }); }
};
const getAllUsers = async (req, res) => {
  try { res.json({ success: true, users: await User.getAllUsers() }); }
  catch (e) { res.status(500).json({ message: 'Server error' }); }
};

module.exports = { getDashboardStats, createHotel, updateHotel, deleteHotel, createRoom, updateRoom, deleteRoom, getAllBookings, getAllUsers };
