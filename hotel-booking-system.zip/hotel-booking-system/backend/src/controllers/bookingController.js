const Booking = require('../models/Booking');
const Room = require('../models/Room');
const { validationResult } = require('express-validator');
const { sendBookingConfirmation } = require('../utils/emailService');

const createBooking = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    const { room_id, check_in_date, check_out_date, guest_count, special_requests } = req.body;
    if (!(await Room.checkAvailability(room_id, check_in_date, check_out_date)))
      return res.status(400).json({ message: 'Room not available for selected dates' });
    const room = await Room.findById(room_id);
    if (!room) return res.status(404).json({ message: 'Room not found' });
    const days = Math.ceil((new Date(check_out_date) - new Date(check_in_date)) / 86400000);
    const total_price = days * room.price_per_night;
    const bookingId = await Booking.create({ user_id: req.user.id, room_id, check_in_date, check_out_date, total_price, guest_count, special_requests });
    const booking = await Booking.findById(bookingId);
    try { await sendBookingConfirmation(req.user.email, booking, room); } catch (e) { console.error('Email error:', e); }
    res.status(201).json({ success: true, booking });
  } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
};

const getUserBookings = async (req, res) => {
  try { res.json({ success: true, bookings: await Booking.findByUser(req.user.id) }); }
  catch (e) { res.status(500).json({ message: 'Server error' }); }
};

const cancelBooking = async (req, res) => {
  try {
    const cancelled = await Booking.cancel(req.params.id, req.user.id);
    if (cancelled) res.json({ success: true, message: 'Booking cancelled successfully' });
    else res.status(400).json({ message: 'Unable to cancel booking' });
  } catch (e) { res.status(500).json({ message: 'Server error' }); }
};

module.exports = { createBooking, getUserBookings, cancelBooking };
