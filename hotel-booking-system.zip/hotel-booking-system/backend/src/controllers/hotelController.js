const Hotel = require('../models/Hotel');

const getHotels = async (req, res) => {
  try { res.json({ success: true, hotels: await Hotel.getHotelsWithRooms(req.query) }); }
  catch (e) { res.status(500).json({ message: 'Server error' }); }
};

const getHotelById = async (req, res) => {
  try {
    const hotel = await Hotel.findById(req.params.id);
    if (!hotel) return res.status(404).json({ message: 'Hotel not found' });
    res.json({ success: true, hotel });
  } catch (e) { res.status(500).json({ message: 'Server error' }); }
};

module.exports = { getHotels, getHotelById };
