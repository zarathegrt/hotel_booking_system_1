const Room = require('../models/Room');

const getRoomsByHotel = async (req, res) => {
  try { res.json({ success: true, rooms: await Room.findByHotel(req.params.hotelId) }); }
  catch (e) { res.status(500).json({ message: 'Server error' }); }
};

const getAvailableRooms = async (req, res) => {
  try {
    const { hotelId, checkIn, checkOut, type } = req.query;
    res.json({ success: true, rooms: await Room.getAvailableRooms(hotelId, checkIn, checkOut, type) });
  } catch (e) { res.status(500).json({ message: 'Server error' }); }
};

module.exports = { getRoomsByHotel, getAvailableRooms };
