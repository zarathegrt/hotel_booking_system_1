const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const { validationResult } = require('express-validator');

const generateToken = (id) => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE });

const register = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    const { name, email, password, phone } = req.body;
    if (await User.findByEmail(email)) return res.status(400).json({ message: 'User already exists' });
    const userId = await User.create({ name, email, password, phone });
    const user = await User.findById(userId);
    res.status(201).json({ success: true, token: generateToken(user.id), user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
};

const login = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    const { email, password } = req.body;
    const user = await User.findByEmail(email);
    if (!user || !(await bcrypt.compare(password, user.password)))
      return res.status(401).json({ message: 'Invalid credentials' });
    res.json({ success: true, token: generateToken(user.id), user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (e) { console.error(e); res.status(500).json({ message: 'Server error' }); }
};

const getProfile = async (req, res) => {
  try { res.json({ success: true, user: await User.findById(req.user.id) }); }
  catch (e) { res.status(500).json({ message: 'Server error' }); }
};

const updateProfile = async (req, res) => {
  try {
    const updated = await User.updateProfile(req.user.id, req.body);
    if (updated) res.json({ success: true, user: await User.findById(req.user.id) });
    else res.status(400).json({ message: 'Update failed' });
  } catch (e) { res.status(500).json({ message: 'Server error' }); }
};

module.exports = { register, login, getProfile, updateProfile };
