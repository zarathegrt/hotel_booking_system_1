const router = require('express').Router();
const { body } = require('express-validator');
const { createBooking, getUserBookings, cancelBooking } = require('../controllers/bookingController');
const { protect } = require('../middleware/auth');

router.use(protect);
router.post('/', [body('room_id').isInt(), body('check_in_date').isDate(), body('check_out_date').isDate(), body('guest_count').isInt({ min: 1 })], createBooking);
router.get('/', getUserBookings);
router.put('/:id/cancel', cancelBooking);
module.exports = router;
