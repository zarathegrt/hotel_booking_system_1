const router = require('express').Router();
const { body } = require('express-validator');
const { register, login, getProfile, updateProfile } = require('../controllers/authController');
const { protect } = require('../middleware/auth');

router.post('/register', [body('email').isEmail().normalizeEmail(), body('password').isLength({ min: 6 }), body('name').notEmpty()], register);
router.post('/login', [body('email').isEmail(), body('password').notEmpty()], login);
router.get('/profile', protect, getProfile);
router.put('/profile', protect, updateProfile);

module.exports = router;
