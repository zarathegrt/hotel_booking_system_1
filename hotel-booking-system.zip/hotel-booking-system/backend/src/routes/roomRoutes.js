const router = require('express').Router();
const { getRoomsByHotel, getAvailableRooms } = require('../controllers/roomController');
router.get('/hotel/:hotelId', getRoomsByHotel);
router.get('/available', getAvailableRooms);
module.exports = router;
