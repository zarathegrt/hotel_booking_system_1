const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST, port: process.env.EMAIL_PORT, secure: false,
  auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS }
});

const sendBookingConfirmation = async (userEmail, booking, room) => {
  await transporter.sendMail({
    from: `"Hotel Booking System" <${process.env.EMAIL_USER}>`,
    to: userEmail,
    subject: 'Booking Confirmation',
    html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">
      <h2>Booking Confirmation</h2>
      <p>Dear ${booking.user_name},</p>
      <p>Your booking has been confirmed!</p>
      <ul>
        <li><strong>Booking ID:</strong> ${booking.id}</li>
        <li><strong>Hotel:</strong> ${booking.hotel_name}</li>
        <li><strong>Room:</strong> ${booking.room_number} (${booking.type})</li>
        <li><strong>Check-in:</strong> ${new Date(booking.check_in_date).toLocaleDateString()}</li>
        <li><strong>Check-out:</strong> ${new Date(booking.check_out_date).toLocaleDateString()}</li>
        <li><strong>Total:</strong> $${booking.total_price}</li>
      </ul>
      <p>Thank you for choosing our service!</p>
    </div>`
  });
};

module.exports = { sendBookingConfirmation };
