const { pool } = require('../config/database');

class Hotel {
  static async create({ name, description, address, city, state, country, zip_code, image_url }) {
    const [r] = await pool.execute('INSERT INTO hotels (name,description,address,city,state,country,zip_code,image_url) VALUES (?,?,?,?,?,?,?,?)', [name,description,address,city,state,country,zip_code,image_url]);
    return r.insertId;
  }
  static async findAll(filters = {}) {
    let q = 'SELECT * FROM hotels WHERE 1=1'; const p = [];
    if (filters.city) { q += ' AND city LIKE ?'; p.push(`%${filters.city}%`); }
    if (filters.minRating) { q += ' AND rating>=?'; p.push(filters.minRating); }
    q += ' ORDER BY created_at DESC';
    const [rows] = await pool.execute(q, p); return rows;
  }
  static async findById(id) {
    const [rows] = await pool.execute('SELECT * FROM hotels WHERE id=?', [id]); return rows[0];
  }
  static async update(id, { name, description, address, city, state, country, zip_code, rating, image_url }) {
    const [r] = await pool.execute('UPDATE hotels SET name=?,description=?,address=?,city=?,state=?,country=?,zip_code=?,rating=?,image_url=? WHERE id=?', [name,description,address,city,state,country,zip_code,rating,image_url,id]);
    return r.affectedRows > 0;
  }
  static async delete(id) {
    const [r] = await pool.execute('DELETE FROM hotels WHERE id=?', [id]); return r.affectedRows > 0;
  }
  static async getHotelsWithRooms(filters = {}) {
    let q = 'SELECT h.*,COUNT(r.id) as total_rooms,MIN(r.price_per_night) as min_price,MAX(r.price_per_night) as max_price FROM hotels h LEFT JOIN rooms r ON h.id=r.hotel_id WHERE 1=1';
    const p = [];
    if (filters.city) { q += ' AND h.city LIKE ?'; p.push(`%${filters.city}%`); }
    q += ' GROUP BY h.id ORDER BY h.created_at DESC';
    const [rows] = await pool.execute(q, p); return rows;
  }
}
module.exports = Hotel;
