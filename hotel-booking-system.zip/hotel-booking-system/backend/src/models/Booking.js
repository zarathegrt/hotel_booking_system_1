const { pool } = require('../config/database');

class Booking {
  static async create({ user_id, room_id, check_in_date, check_out_date, total_price, guest_count, special_requests }) {
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      const [r] = await conn.execute("INSERT INTO bookings (user_id,room_id,check_in_date,check_out_date,total_price,guest_count,special_requests,status) VALUES (?,?,?,?,?,?,?,'confirmed')", [user_id,room_id,check_in_date,check_out_date,total_price,guest_count,special_requests]);
      await conn.commit(); return r.insertId;
    } catch(e) { await conn.rollback(); throw e; } finally { conn.release(); }
  }
  static async findByUser(userId) {
    const [rows] = await pool.execute('SELECT b.*,r.room_number,r.type,h.name as hotel_name,h.city,h.address FROM bookings b JOIN rooms r ON b.room_id=r.id JOIN hotels h ON r.hotel_id=h.id WHERE b.user_id=? ORDER BY b.created_at DESC', [userId]);
    return rows;
  }
  static async findById(id) {
    const [rows] = await pool.execute('SELECT b.*,r.room_number,r.type,h.name as hotel_name,h.city,h.address,u.name as user_name,u.email as user_email FROM bookings b JOIN rooms r ON b.room_id=r.id JOIN hotels h ON r.hotel_id=h.id JOIN users u ON b.user_id=u.id WHERE b.id=?', [id]);
    return rows[0];
  }
  static async cancel(id, userId) {
    const [r] = await pool.execute('UPDATE bookings SET status="cancelled" WHERE id=? AND user_id=? AND status="confirmed"', [id,userId]);
    return r.affectedRows > 0;
  }
  static async getAllBookings(filters = {}) {
    let q = 'SELECT b.*,r.room_number,h.name as hotel_name,u.name as user_name,u.email as user_email FROM bookings b JOIN rooms r ON b.room_id=r.id JOIN hotels h ON r.hotel_id=h.id JOIN users u ON b.user_id=u.id WHERE 1=1';
    const p = [];
    if (filters.status) { q += ' AND b.status=?'; p.push(filters.status); }
    q += ' ORDER BY b.created_at DESC';
    const [rows] = await pool.execute(q, p); return rows;
  }
  static async getDashboardStats() {
    const [s] = await pool.execute("SELECT (SELECT COUNT(*) FROM users WHERE role='user') as total_users,(SELECT COUNT(*) FROM bookings WHERE status='confirmed') as total_bookings,(SELECT COALESCE(SUM(total_price),0) FROM bookings WHERE status='confirmed') as total_revenue,(SELECT COUNT(*) FROM hotels) as total_hotels,(SELECT COUNT(*) FROM rooms) as total_rooms");
    return s[0];
  }
}
module.exports = Booking;
