const { pool } = require('../config/database');
const bcrypt = require('bcryptjs');

class User {
  static async create({ name, email, password, phone, role = 'user' }) {
    const hash = await bcrypt.hash(password, 10);
    const [r] = await pool.execute('INSERT INTO users (name,email,password,phone,role) VALUES (?,?,?,?,?)', [name,email,hash,phone,role]);
    return r.insertId;
  }
  static async findByEmail(email) {
    const [rows] = await pool.execute('SELECT * FROM users WHERE email=?', [email]);
    return rows[0];
  }
  static async findById(id) {
    const [rows] = await pool.execute('SELECT id,name,email,phone,role,created_at FROM users WHERE id=?', [id]);
    return rows[0];
  }
  static async updateProfile(id, { name, phone }) {
    const [r] = await pool.execute('UPDATE users SET name=?,phone=? WHERE id=?', [name,phone,id]);
    return r.affectedRows > 0;
  }
  static async updatePassword(id, newPassword) {
    const hash = await bcrypt.hash(newPassword, 10);
    const [r] = await pool.execute('UPDATE users SET password=? WHERE id=?', [hash,id]);
    return r.affectedRows > 0;
  }
  static async getAllUsers() {
    const [rows] = await pool.execute('SELECT id,name,email,phone,role,created_at FROM users');
    return rows;
  }
}

module.exports = User;
