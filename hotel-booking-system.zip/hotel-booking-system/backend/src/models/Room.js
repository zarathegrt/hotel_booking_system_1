const { pool } = require('../config/database');

class Room {
  static async create({ hotel_id, room_number, type, price_per_night, capacity, description, image_url }) {
    const [r] = await pool.execute('INSERT INTO rooms (hotel_id,room_number,type,price_per_night,capacity,description,image_url) VALUES (?,?,?,?,?,?,?)', [hotel_id,room_number,type,price_per_night,capacity,description,image_url]);
    return r.insertId;
  }
  static async findByHotel(hotelId) {
    const [rows] = await pool.execute('SELECT * FROM rooms WHERE hotel_id=? ORDER BY room_number', [hotelId]); return rows;
  }
  static async findById(id) {
    const [rows] = await pool.execute('SELECT r.*,h.name as hotel_name,h.city FROM rooms r JOIN hotels h ON r.hotel_id=h.id WHERE r.id=?', [id]); return rows[0];
  }
  static async update(id, { room_number, type, price_per_night, capacity, description, is_available, image_url }) {
    const [r] = await pool.execute('UPDATE rooms SET room_number=?,type=?,price_per_night=?,capacity=?,description=?,is_available=?,image_url=? WHERE id=?', [room_number,type,price_per_night,capacity,description,is_available,image_url,id]);
    return r.affectedRows > 0;
  }
  static async delete(id) {
    const [r] = await pool.execute('DELETE FROM rooms WHERE id=?', [id]); return r.affectedRows > 0;
  }
  static async checkAvailability(roomId, checkIn, checkOut) {
    const [rows] = await pool.execute("SELECT COUNT(*) as n FROM bookings WHERE room_id=? AND status!='cancelled' AND ((check_in_date<=? AND check_out_date>?) OR (check_in_date<? AND check_out_date>=?) OR (check_in_date>=? AND check_out_date<=?))", [roomId,checkOut,checkIn,checkOut,checkIn,checkIn,checkOut]);
    return rows[0].n === 0;
  }
  static async getAvailableRooms(hotelId, checkIn, checkOut, type = null) {
    let q = "SELECT r.* FROM rooms r WHERE r.hotel_id=? AND r.is_available=true AND NOT EXISTS (SELECT 1 FROM bookings b WHERE b.room_id=r.id AND b.status!='cancelled' AND ((b.check_in_date<=? AND b.check_out_date>?) OR (b.check_in_date<? AND b.check_out_date>=?) OR (b.check_in_date>=? AND b.check_out_date<=?)))";
    const p = [hotelId,checkOut,checkIn,checkOut,checkIn,checkIn,checkOut];
    if (type) { q += ' AND r.type=?'; p.push(type); }
    const [rows] = await pool.execute(q, p); return rows;
  }
}
module.exports = Room;
