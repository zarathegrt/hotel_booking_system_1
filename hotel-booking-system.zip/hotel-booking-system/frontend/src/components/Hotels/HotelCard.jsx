import React from 'react';
import { Link } from 'react-router-dom';

const HotelCard = ({ hotel }) => (
  <div className="card group">
    <div className="relative h-48 overflow-hidden">
      <img src={hotel.image_url || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=500'} alt={hotel.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
    </div>
    <div className="p-4">
      <h3 className="text-xl font-bold text-gray-800 dark:text-white">{hotel.name}</h3>
      <p className="text-gray-500 text-sm">📍 {hotel.city}, {hotel.country}</p>
      <Link to={`/hotels/${hotel.id}`} className="mt-3 block text-center btn-primary py-2 text-sm">View Details</Link>
    </div>
  </div>
);
export default HotelCard;
