import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import api from '../../services/api';
import Loader from '../Common/Loader';
import BookingForm from '../Bookings/BookingForm';
import { useAuth } from '../../context/AuthContext';

const HotelDetail = () => {
  const { id } = useParams();
  const [hotel, setHotel] = useState(null);
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const { user } = useAuth();

  useEffect(() => {
    const load = async () => {
      try {
        const [hRes, rRes] = await Promise.all([api.get(`/hotels/${id}`), api.get(`/rooms/hotel/${id}`)]);
        setHotel(hRes.data.hotel);
        setRooms(rRes.data.rooms || []);
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    };
    load();
  }, [id]);

  if (loading) return <Loader />;
  if (!hotel) return <div className="text-center py-16 text-gray-500">Hotel not found</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden mb-8">
        <img src={hotel.image_url || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1200'} alt={hotel.name} className="w-full h-72 object-cover" />
        <div className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">{hotel.name}</h1>
              <p className="text-gray-500 mb-2">📍 {hotel.address}, {hotel.city}, {hotel.country}</p>
              <p className="text-yellow-500 font-semibold">★ {hotel.rating || 'Unrated'}</p>
            </div>
          </div>
          <p className="text-gray-600 dark:text-gray-400 mt-4">{hotel.description}</p>
        </div>
      </div>

      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">Available Rooms</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {rooms.map(room => (
          <div key={room.id} className="card p-4">
            <img src={room.image_url || 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400'} alt={room.type} className="w-full h-40 object-cover rounded-lg mb-3" />
            <h3 className="text-lg font-bold capitalize text-gray-800 dark:text-white">{room.type} Room</h3>
            <p className="text-gray-500 text-sm">Room #{room.room_number} • {room.capacity} guests</p>
            <p className="text-gray-600 dark:text-gray-400 text-sm mt-1 mb-3">{room.description}</p>
            <div className="flex justify-between items-center">
              <span className="text-blue-600 font-bold text-lg">${room.price_per_night}<span className="text-sm font-normal text-gray-500">/night</span></span>
              {room.is_available ? (
                <button onClick={() => user ? setSelectedRoom(room) : window.location.href='/login'} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-sm">
                  Book Now
                </button>
              ) : <span className="text-red-500 text-sm font-medium">Unavailable</span>}
            </div>
          </div>
        ))}
      </div>

      {rooms.length === 0 && <p className="text-center text-gray-500 py-8">No rooms available for this hotel.</p>}

      {selectedRoom && <BookingForm room={selectedRoom} hotel={hotel} onClose={() => setSelectedRoom(null)} />}
    </div>
  );
};
export default HotelDetail;
