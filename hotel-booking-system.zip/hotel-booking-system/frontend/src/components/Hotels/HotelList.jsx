import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api';
import Loader from '../Common/Loader';

const HotelList = () => {
  const [hotels, setHotels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ city: '', minPrice: '', maxPrice: '' });

  useEffect(() => { fetchHotels(); }, []);

  const fetchHotels = async (params = {}) => {
    setLoading(true);
    try {
      const res = await api.get('/hotels', { params });
      setHotels(res.data.hotels || []);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  if (loading) return <Loader />;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-2">Find Your Perfect Hotel</h1>
        <p className="text-gray-500 dark:text-gray-400">Discover amazing places to stay</p>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-8">
        <div className="grid md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">City</label>
            <input type="text" placeholder="Enter city" className="input-field" value={filters.city} onChange={e => setFilters({...filters, city: e.target.value})} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Min Price</label>
            <input type="number" placeholder="$0" className="input-field" value={filters.minPrice} onChange={e => setFilters({...filters, minPrice: e.target.value})} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Max Price</label>
            <input type="number" placeholder="$1000" className="input-field" value={filters.maxPrice} onChange={e => setFilters({...filters, maxPrice: e.target.value})} />
          </div>
          <div className="flex items-end">
            <button onClick={() => fetchHotels(filters)} className="w-full btn-primary">🔍 Search</button>
          </div>
        </div>
      </div>

      {hotels.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-5xl mb-4">🏨</p>
          <p className="text-gray-500 dark:text-gray-400 text-lg">No hotels found. Try different filters.</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {hotels.map(hotel => (
            <div key={hotel.id} className="card group">
              <div className="relative h-48 overflow-hidden">
                <img src={hotel.image_url || `https://images.unsplash.com/photo-1566073771259-6a8506099945?w=500&auto=format`} alt={hotel.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                <div className="absolute top-2 right-2 bg-white dark:bg-gray-800 rounded-full px-2 py-1 text-sm font-semibold text-yellow-500">
                  ★ {hotel.rating || 'New'}
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-1">{hotel.name}</h3>
                <p className="text-gray-500 text-sm mb-2">📍 {hotel.city}, {hotel.country}</p>
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-3 line-clamp-2">{hotel.description || 'A wonderful place to stay.'}</p>
                <div className="flex items-center justify-between">
                  <span className="text-blue-600 font-bold text-lg">from ${hotel.min_price || '99'}<span className="text-sm font-normal text-gray-500">/night</span></span>
                  <Link to={`/hotels/${hotel.id}`} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">View Rooms</Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
export default HotelList;
