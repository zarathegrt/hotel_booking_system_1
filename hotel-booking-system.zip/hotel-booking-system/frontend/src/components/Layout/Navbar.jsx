import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [dark, setDark] = useState(false);

  const toggleDark = () => {
    setDark(!dark);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <nav className="bg-white dark:bg-gray-800 shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold text-blue-600">🏨 HotelBook</Link>
        <div className="flex items-center gap-4">
          <Link to="/" className="text-gray-600 dark:text-gray-300 hover:text-blue-600">Hotels</Link>
          {user ? (
            <>
              <Link to="/bookings" className="text-gray-600 dark:text-gray-300 hover:text-blue-600">My Bookings</Link>
              {user.role === 'admin' && <Link to="/admin" className="text-gray-600 dark:text-gray-300 hover:text-blue-600">Admin</Link>}
              <span className="text-gray-600 dark:text-gray-300">Hi, {user.name}</span>
              <button onClick={logout} className="btn-primary text-sm py-1.5 px-4">Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className="text-gray-600 dark:text-gray-300 hover:text-blue-600">Login</Link>
              <Link to="/register" className="btn-primary text-sm py-1.5 px-4">Register</Link>
            </>
          )}
          <button onClick={toggleDark} className="text-xl">{dark ? '☀️' : '🌙'}</button>
        </div>
      </div>
    </nav>
  );
};
export default Navbar;
