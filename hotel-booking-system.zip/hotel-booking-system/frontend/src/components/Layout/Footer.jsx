import React from 'react';

const Footer = () => (
  <footer className="bg-gray-800 text-white py-8 mt-auto">
    <div className="max-w-7xl mx-auto px-4 text-center">
      <p className="text-2xl font-bold mb-2">🏨 HotelBook</p>
      <p className="text-gray-400 mb-4">Find and book your perfect stay</p>
      <p className="text-gray-500 text-sm">© {new Date().getFullYear()} HotelBook. All rights reserved.</p>
    </div>
  </footer>
);
export default Footer;
