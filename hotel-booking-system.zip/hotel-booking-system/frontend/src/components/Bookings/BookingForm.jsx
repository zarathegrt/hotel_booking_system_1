import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import toast from 'react-hot-toast';

const BookingForm = ({ room, hotel, onClose }) => {
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guestCount, setGuestCount] = useState(1);
  const [specialRequests, setSpecialRequests] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const totalDays = checkIn && checkOut ? Math.max(0, Math.ceil((new Date(checkOut) - new Date(checkIn)) / 86400000)) : 0;
  const totalPrice = totalDays * room.price_per_night;

  const handleBooking = async () => {
    if (!checkIn || !checkOut || totalDays < 1) { toast.error('Please select valid dates'); return; }
    setLoading(true);
    try {
      await api.post('/bookings', { room_id: room.id, check_in_date: checkIn, check_out_date: checkOut, guest_count: guestCount, special_requests: specialRequests });
      toast.success('Booking confirmed!');
      onClose();
      navigate('/bookings');
    } catch (e) { toast.error(e.response?.data?.message || 'Booking failed'); }
    finally { setLoading(false); }
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Book Your Stay</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700 text-2xl">×</button>
          </div>
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 mb-4">
            <h3 className="font-semibold text-gray-800 dark:text-white">{hotel.name}</h3>
            <p className="text-gray-500 text-sm capitalize">{room.type} Room #{room.room_number}</p>
            <p className="text-blue-600 font-bold">${room.price_per_night}/night</p>
          </div>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Check-in</label>
                <input type="date" min={today} value={checkIn} onChange={e => setCheckIn(e.target.value)} className="input-field" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Check-out</label>
                <input type="date" min={checkIn || today} value={checkOut} onChange={e => setCheckOut(e.target.value)} className="input-field" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Guests</label>
              <input type="number" min="1" max={room.capacity} value={guestCount} onChange={e => setGuestCount(parseInt(e.target.value))} className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Special Requests</label>
              <textarea rows="2" value={specialRequests} onChange={e => setSpecialRequests(e.target.value)} className="input-field" placeholder="Any special requests?" />
            </div>
            {totalDays > 0 && (
              <div className="border-t dark:border-gray-600 pt-4 space-y-1">
                <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400">
                  <span>${room.price_per_night} × {totalDays} nights</span><span>${room.price_per_night * totalDays}</span>
                </div>
                <div className="flex justify-between font-bold text-lg text-gray-800 dark:text-white">
                  <span>Total</span><span>${totalPrice}</span>
                </div>
              </div>
            )}
            <button onClick={handleBooking} disabled={loading || totalDays < 1} className="w-full btn-primary py-3 disabled:opacity-50">
              {loading ? 'Processing...' : 'Confirm Booking'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default BookingForm;
