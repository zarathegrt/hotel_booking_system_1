import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import Loader from '../Common/Loader';
import toast from 'react-hot-toast';

const statusColors = { confirmed: 'bg-green-100 text-green-800', pending: 'bg-yellow-100 text-yellow-800', cancelled: 'bg-red-100 text-red-800', completed: 'bg-blue-100 text-blue-800' };

const BookingHistory = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchBookings(); }, []);

  const fetchBookings = async () => {
    try {
      const res = await api.get('/bookings');
      setBookings(res.data.bookings || []);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const cancelBooking = async (id) => {
    if (!confirm('Cancel this booking?')) return;
    try {
      await api.put(`/bookings/${id}/cancel`);
      toast.success('Booking cancelled');
      fetchBookings();
    } catch (e) { toast.error(e.response?.data?.message || 'Failed to cancel'); }
  };

  if (loading) return <Loader />;

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-8">My Bookings</h1>
      {bookings.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-5xl mb-4">📋</p>
          <p className="text-gray-500 text-lg">No bookings yet.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {bookings.map(b => (
            <div key={b.id} className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
              <div className="flex justify-between items-start flex-wrap gap-4">
                <div>
                  <h3 className="text-xl font-bold text-gray-800 dark:text-white">{b.hotel_name}</h3>
                  <p className="text-gray-500 text-sm capitalize">{b.type} Room #{b.room_number} • {b.city}</p>
                  <p className="text-gray-500 text-sm mt-1">📅 {new Date(b.check_in_date).toLocaleDateString()} → {new Date(b.check_out_date).toLocaleDateString()}</p>
                  {b.special_requests && <p className="text-gray-500 text-sm mt-1">💬 {b.special_requests}</p>}
                </div>
                <div className="text-right">
                  <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${statusColors[b.status] || ''}`}>{b.status}</span>
                  <p className="text-blue-600 font-bold text-xl mt-2">${b.total_price}</p>
                  {b.status === 'confirmed' && (
                    <button onClick={() => cancelBooking(b.id)} className="mt-2 text-red-500 hover:text-red-700 text-sm underline">Cancel Booking</button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
export default BookingHistory;
