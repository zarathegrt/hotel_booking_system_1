import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import toast from 'react-hot-toast';

const RoomManagement = () => {
  const [rooms, setRooms] = useState([]);
  const [hotels, setHotels] = useState([]);
  const [form, setForm] = useState({ hotel_id:'', room_number:'', type:'single', price_per_night:'', capacity:'', description:'', image_url:'' });
  const [editId, setEditId] = useState(null);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    api.get('/hotels').then(r => setHotels(r.data.hotels || [])).catch(console.error);
  }, []);

  useEffect(() => {
    if (form.hotel_id) api.get(`/rooms/hotel/${form.hotel_id}`).then(r => setRooms(r.data.rooms || [])).catch(console.error);
  }, [form.hotel_id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editId) { await api.put(`/admin/rooms/${editId}`, form); toast.success('Room updated'); }
      else { await api.post('/admin/rooms', form); toast.success('Room created'); }
      if (form.hotel_id) { const r = await api.get(`/rooms/hotel/${form.hotel_id}`); setRooms(r.data.rooms || []); }
      setShowForm(false); setEditId(null);
    } catch (e) { toast.error(e.response?.data?.message || 'Error'); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete room?')) return;
    try { await api.delete(`/admin/rooms/${id}`); toast.success('Room deleted'); setRooms(rooms.filter(r => r.id !== id)); }
    catch (e) { toast.error('Delete failed'); }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Room Management</h2>
        <button onClick={() => setShowForm(!showForm)} className="btn-primary">{showForm ? 'Cancel' : '+ Add Room'}</button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-6">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Hotel</label>
              <select className="input-field" value={form.hotel_id} onChange={e => setForm({...form, hotel_id: e.target.value})} required>
                <option value="">Select hotel</option>
                {hotels.map(h => <option key={h.id} value={h.id}>{h.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Room Type</label>
              <select className="input-field" value={form.type} onChange={e => setForm({...form, type: e.target.value})}>
                {['single','double','suite','deluxe'].map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            {[['room_number','Room Number'],['price_per_night','Price/Night'],['capacity','Capacity'],['image_url','Image URL']].map(([field,label]) => (
              <div key={field}>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{label}</label>
                <input type={field === 'price_per_night' || field === 'capacity' ? 'number' : 'text'} className="input-field" value={form[field]} onChange={e => setForm({...form, [field]: e.target.value})} required={field !== 'image_url'} />
              </div>
            ))}
          </div>
          <button type="submit" className="mt-4 btn-primary">{editId ? 'Update Room' : 'Create Room'}</button>
        </form>
      )}

      <div>
        <div className="mb-4">
          <select className="input-field max-w-xs" onChange={e => { setForm(f => ({...f, hotel_id: e.target.value})); }}>
            <option value="">Filter by hotel</option>
            {hotels.map(h => <option key={h.id} value={h.id}>{h.name}</option>)}
          </select>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>{['Room #','Type','Price/Night','Capacity','Available','Actions'].map(h => <th key={h} className="px-4 py-3 text-left text-gray-700 dark:text-gray-300 font-medium">{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {rooms.map(r => (
                <tr key={r.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-4 py-3 text-gray-800 dark:text-white">{r.room_number}</td>
                  <td className="px-4 py-3 text-gray-600 dark:text-gray-400 capitalize">{r.type}</td>
                  <td className="px-4 py-3 text-gray-600 dark:text-gray-400">${r.price_per_night}</td>
                  <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{r.capacity}</td>
                  <td className="px-4 py-3"><span className={`px-2 py-1 rounded-full text-xs ${r.is_available ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{r.is_available ? 'Yes' : 'No'}</span></td>
                  <td className="px-4 py-3"><button onClick={() => handleDelete(r.id)} className="text-red-500 hover:text-red-700 text-sm">Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          {rooms.length === 0 && <p className="text-center text-gray-500 py-8">No rooms. Select a hotel to view rooms.</p>}
        </div>
      </div>
    </div>
  );
};
export default RoomManagement;
