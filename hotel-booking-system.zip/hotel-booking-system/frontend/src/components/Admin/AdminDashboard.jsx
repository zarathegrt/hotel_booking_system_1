import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import api from '../../services/api';
import HotelManagement from './HotelManagement';
import RoomManagement from './RoomManagement';
import BookingsView from './BookingsView';

const revenueData = [
  { month: 'Jan', revenue: 5000 }, { month: 'Feb', revenue: 7500 }, { month: 'Mar', revenue: 10000 },
  { month: 'Apr', revenue: 8500 }, { month: 'May', revenue: 12000 }, { month: 'Jun', revenue: 15000 }
];

const AdminDashboard = () => {
  const [stats, setStats] = useState({ total_users: 0, total_bookings: 0, total_revenue: 0, total_hotels: 0, total_rooms: 0 });
  const location = useLocation();

  useEffect(() => {
    api.get('/admin/stats').then(r => setStats(r.data.stats)).catch(console.error);
  }, []);

  const navLinks = [
    { path: '/admin', label: '📊 Dashboard' },
    { path: '/admin/hotels', label: '🏨 Hotels' },
    { path: '/admin/rooms', label: '🛏️ Rooms' },
    { path: '/admin/bookings', label: '📋 Bookings' },
  ];

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 flex">
      <div className="w-56 bg-white dark:bg-gray-800 shadow-lg min-h-screen flex-shrink-0">
        <div className="p-4">
          <h2 className="text-lg font-bold text-gray-800 dark:text-white mb-6">Admin Panel</h2>
          <nav className="space-y-1">
            {navLinks.map(({ path, label }) => (
              <Link key={path} to={path} className={`flex items-center px-3 py-2 rounded-lg text-sm transition-colors ${location.pathname === path ? 'bg-blue-100 text-blue-700 font-medium' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}`}>
                {label}
              </Link>
            ))}
          </nav>
        </div>
      </div>
      <div className="flex-1 p-6 overflow-auto">
        <Routes>
          <Route path="/" element={
            <>
              <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">Dashboard</h1>
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
                {[['👥 Users', stats.total_users, 'text-blue-500'],['🏨 Hotels', stats.total_hotels, 'text-green-500'],['🛏️ Rooms', stats.total_rooms, 'text-purple-500'],['📋 Bookings', stats.total_bookings, 'text-yellow-500'],['💰 Revenue', `$${stats.total_revenue}`, 'text-emerald-500']].map(([label, val, color]) => (
                  <div key={label} className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-md">
                    <p className="text-gray-500 dark:text-gray-400 text-sm">{label}</p>
                    <p className={`text-2xl font-bold ${color}`}>{val}</p>
                  </div>
                ))}
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
                  <h3 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">Revenue Trend</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={revenueData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="month" /><YAxis /><Tooltip /><Legend /><Line type="monotone" dataKey="revenue" stroke="#3b82f6" /></LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
                  <h3 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">Monthly Revenue</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={revenueData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="month" /><YAxis /><Tooltip /><Legend /><Bar dataKey="revenue" fill="#3b82f6" /></BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </>
          } />
          <Route path="hotels/*" element={<HotelManagement />} />
          <Route path="rooms/*" element={<RoomManagement />} />
          <Route path="bookings" element={<BookingsView />} />
        </Routes>
      </div>
    </div>
  );
};
export default AdminDashboard;
