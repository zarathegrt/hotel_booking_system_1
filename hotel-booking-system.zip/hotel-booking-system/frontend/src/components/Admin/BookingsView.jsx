import React, { useState, useEffect } from 'react';
import api from '../../services/api';

const statusColors = { confirmed: 'bg-green-100 text-green-800', pending: 'bg-yellow-100 text-yellow-800', cancelled: 'bg-red-100 text-red-800', completed: 'bg-blue-100 text-blue-800' };

const BookingsView = () => {
  const [bookings, setBookings] = useState([]);
  const [filter, setFilter] = useState('');

  useEffect(() => { api.get('/admin/bookings', { params: filter ? { status: filter } : {} }).then(r => setBookings(r.data.bookings || [])).catch(console.error); }, [filter]);

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white">All Bookings</h2>
        <select className="input-field max-w-xs" value={filter} onChange={e => setFilter(e.target.value)}>
          <option value="">All statuses</option>
          {['confirmed','pending','cancelled','completed'].map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>{['ID','Guest','Hotel','Room','Check-in','Check-out','Total','Status'].map(h => <th key={h} className="px-4 py-3 text-left text-gray-700 dark:text-gray-300 font-medium">{h}</th>)}</tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
            {bookings.map(b => (
              <tr key={b.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                <td className="px-4 py-3 text-gray-800 dark:text-white">#{b.id}</td>
                <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{b.user_name}</td>
                <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{b.hotel_name}</td>
                <td className="px-4 py-3 text-gray-600 dark:text-gray-400">#{b.room_number}</td>
                <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{new Date(b.check_in_date).toLocaleDateString()}</td>
                <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{new Date(b.check_out_date).toLocaleDateString()}</td>
                <td className="px-4 py-3 text-blue-600 font-medium">${b.total_price}</td>
                <td className="px-4 py-3"><span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[b.status] || ''}`}>{b.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
        {bookings.length === 0 && <p className="text-center text-gray-500 py-8">No bookings found.</p>}
      </div>
    </div>
  );
};
export default BookingsView;
