import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import toast from 'react-hot-toast';

const HotelManagement = () => {
  const [hotels, setHotels] = useState([]);
  const [form, setForm] = useState({ name:'', description:'', address:'', city:'', state:'', country:'', zip_code:'', image_url:'' });
  const [editId, setEditId] = useState(null);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => { fetchHotels(); }, []);

  const fetchHotels = async () => {
    try { const r = await api.get('/hotels'); setHotels(r.data.hotels || []); } catch (e) { console.error(e); }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editId) { await api.put(`/admin/hotels/${editId}`, form); toast.success('Hotel updated'); }
      else { await api.post('/admin/hotels', form); toast.success('Hotel created'); }
      fetchHotels(); setShowForm(false); setEditId(null); setForm({ name:'', description:'', address:'', city:'', state:'', country:'', zip_code:'', image_url:'' });
    } catch (e) { toast.error(e.response?.data?.message || 'Error'); }
  };

  const handleEdit = (hotel) => { setForm(hotel); setEditId(hotel.id); setShowForm(true); };

  const handleDelete = async (id) => {
    if (!confirm('Delete hotel?')) return;
    try { await api.delete(`/admin/hotels/${id}`); toast.success('Hotel deleted'); fetchHotels(); }
    catch (e) { toast.error('Delete failed'); }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Hotel Management</h2>
        <button onClick={() => { setShowForm(!showForm); setEditId(null); }} className="btn-primary">{showForm ? 'Cancel' : '+ Add Hotel'}</button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-6">
          <div className="grid md:grid-cols-2 gap-4">
            {['name','description','address','city','state','country','zip_code','image_url'].map(field => (
              <div key={field}>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 capitalize">{field.replace('_',' ')}</label>
                <input type="text" className="input-field" value={form[field]} onChange={e => setForm({...form, [field]: e.target.value})} required={['name','address','city','country'].includes(field)} />
              </div>
            ))}
          </div>
          <button type="submit" className="mt-4 btn-primary">{editId ? 'Update Hotel' : 'Create Hotel'}</button>
        </form>
      )}

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>{['Name','City','Country','Rating','Actions'].map(h => <th key={h} className="px-4 py-3 text-left text-gray-700 dark:text-gray-300 font-medium">{h}</th>)}</tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
            {hotels.map(h => (
              <tr key={h.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                <td className="px-4 py-3 text-gray-800 dark:text-white font-medium">{h.name}</td>
                <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{h.city}</td>
                <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{h.country}</td>
                <td className="px-4 py-3 text-yellow-500">★ {h.rating || 'N/A'}</td>
                <td className="px-4 py-3 flex gap-2">
                  <button onClick={() => handleEdit(h)} className="text-blue-600 hover:text-blue-800 text-sm">Edit</button>
                  <button onClick={() => handleDelete(h.id)} className="text-red-500 hover:text-red-700 text-sm">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {hotels.length === 0 && <p className="text-center text-gray-500 py-8">No hotels yet.</p>}
      </div>
    </div>
  );
};
export default HotelManagement;
